#!/usr/bin/env python3
"""
GitHub URL Clone and Python File Extraction
Clones repositories from GitHub URLs in parallel (4 workers) and extracts Python files to a temp folder.
Uses multiprocessing to process up to 4 repositories simultaneously for faster execution.
"""

import os
import csv
import shutil
import subprocess
import logging
from pathlib import Path
from datetime import datetime
import re
from multiprocessing import Pool, Manager

def setup_logging():
    """Set up logging to both file and console."""
    # Create files directory if it doesn't exist
    logs_dir = Path("files")
    logs_dir.mkdir(exist_ok=True)

    # Create log filename with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = logs_dir / f"clone_extract_{timestamp}.log"

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

    return log_file

def get_latest_csv():
    """Find the most recent gmail_extract CSV file."""
    files_dir = Path("files")

    if not files_dir.exists():
        logging.error(f"files directory not found at {files_dir.absolute()}")
        return None

    csv_files = list(files_dir.glob("gmail_extract_*.csv"))

    if not csv_files:
        logging.error("No gmail_extract CSV files found in files/ directory.")
        return None

    # Sort by modification time and get the latest
    latest_csv = max(csv_files, key=lambda f: f.stat().st_mtime)
    return latest_csv

def parse_github_url(url):
    """Parse GitHub URL and extract repository URL and optional subpath.

    Handles URLs like:
    - https://github.com/user/repo
    - https://github.com/user/repo/tree/branch/path/to/folder
    - https://github.com/user/repo.git

    Returns:
        tuple: (repo_url, subpath) where subpath is None if not specified
    """
    url = url.rstrip('/')

    # Remove .git suffix if present
    if url.endswith('.git'):
        url = url[:-4]

    # Match GitHub URL pattern
    # Pattern: https://github.com/user/repo[/tree/branch/path...]
    pattern = r'(https://github\.com/[^/]+/[^/]+)(?:/tree/[^/]+/(.+))?'
    match = re.match(pattern, url)

    if match:
        repo_url = match.group(1)
        subpath = match.group(2) if match.group(2) else None
        return repo_url, subpath

    # If no match, assume it's already a base repo URL
    return url, None

def extract_exercise_name(subject, url):
    """Extract exercise identifier from subject or URL."""
    # Try to extract from subject first
    match = re.search(r'exercise #?(\d+)', subject, re.IGNORECASE)
    if match:
        return f"exercise_{match.group(1)}"

    # Fallback to URL parsing
    match = re.search(r'Lesson(\d+)', url)
    if match:
        return f"exercise_{match.group(1)}"

    # Last resort: use part of URL
    url_parts = url.rstrip('/').split('/')
    return url_parts[-1].replace(' ', '_')[:30] if url_parts else "unknown"

def clone_repo(url, dest_path):
    """Clone a GitHub repository with shallow clone and sparse checkout for specific folders."""
    try:
        # Parse GitHub URL to get the base repository URL
        repo_url, subpath = parse_github_url(url)

        # Create destination directory
        dest_path.mkdir(parents=True, exist_ok=True)

        # If subpath is specified, use sparse checkout
        if subpath:
            # Initialize empty repo with shallow clone and sparse checkout
            result = subprocess.run(
                ['git', 'clone', '--depth', '1', '--filter=blob:none', '--sparse', repo_url, str(dest_path)],
                capture_output=True,
                text=True,
                timeout=180
            )

            if result.returncode != 0:
                error_msg = result.stderr.strip() if result.stderr else "Unknown error"
                return False, error_msg, None

            # Configure sparse-checkout to only include the specific folder
            subprocess.run(
                ['git', '-C', str(dest_path), 'sparse-checkout', 'set', subpath],
                capture_output=True,
                text=True,
                timeout=60
            )

        else:
            # Clone the entire repository with shallow clone
            result = subprocess.run(
                ['git', 'clone', '--depth', '1', repo_url, str(dest_path)],
                capture_output=True,
                text=True,
                timeout=180
            )

            if result.returncode != 0:
                error_msg = result.stderr.strip() if result.stderr else "Unknown error"
                return False, error_msg, None

        return True, "Success", subpath

    except subprocess.TimeoutExpired:
        return False, "Clone operation timed out (180s limit)", None
    except FileNotFoundError:
        return False, "Git command not found. Please install git.", None
    except Exception as e:
        return False, str(e), None

def extract_python_files(repo_path, dest_path, exercise_name, subpath=None):
    """Extract all Python files from a repository or a specific subdirectory.

    Args:
        repo_path: Path to the cloned repository
        dest_path: Destination directory for extracted files
        exercise_name: Name of the exercise
        subpath: Optional subdirectory within the repo to extract from
    """
    skip_dirs = {'__pycache__', '.git', 'venv', 'env', '.venv', 'node_modules', '.ipynb_checkpoints'}
    python_files = []

    # If subpath is specified, start from that subdirectory
    if subpath:
        search_path = repo_path / subpath
        if not search_path.exists():
            logging.warning(f"Subpath '{subpath}' not found in repository")
            search_path = repo_path
    else:
        search_path = repo_path

    if not search_path.exists():
        return python_files

    for root, dirs, files in os.walk(search_path):
        # Remove skip directories from search
        dirs[:] = [d for d in dirs if d not in skip_dirs]

        for file in files:
            if file.endswith('.py'):
                src_file = Path(root) / file

                # Create relative path structure
                try:
                    rel_path = src_file.relative_to(search_path)
                except ValueError:
                    continue

                dest_file = dest_path / exercise_name / rel_path

                # Create destination directory
                dest_file.parent.mkdir(parents=True, exist_ok=True)

                # Copy the file
                try:
                    shutil.copy2(src_file, dest_file)
                    python_files.append(dest_file)
                except Exception as e:
                    logging.warning(f"Could not copy {src_file.name}: {e}")

    return python_files

def process_single_url(args):
    """Process a single URL (designed for multiprocessing).

    Args:
        args: Tuple containing (url, subject, repos_dir, python_dir, index, total)

    Returns:
        dict: Result dictionary with status and details
    """
    url, subject, repos_dir, python_dir, index, total = args

    exercise_name = extract_exercise_name(subject, url)

    # Build result dict
    result = {
        'exercise': exercise_name,
        'url': url,
        'status': 'failed',
        'files': 0,
        'message': '',
        'index': index
    }

    try:
        logging.info(f"[{index}/{total}] Processing: {exercise_name}")
        logging.info(f"    URL: {url}")

        # Clone repository
        repo_path = repos_dir / exercise_name
        success, message, subpath = clone_repo(url, repo_path)

        if success:
            if subpath:
                logging.info(f"    ✓ Cloned successfully (subpath: {subpath})")
            else:
                logging.info(f"    ✓ Cloned successfully")

            # Extract Python files
            py_files = extract_python_files(repo_path, python_dir, exercise_name, subpath)

            logging.info(f"    ✓ Extracted {len(py_files)} Python file(s)")

            result.update({
                'status': 'success',
                'files': len(py_files),
                'message': 'Success'
            })
        else:
            logging.error(f"    ✗ Clone failed: {message}")
            result['message'] = message

        logging.info("")

    except Exception as e:
        error_msg = f"Unexpected error: {str(e)}"
        logging.error(f"    ✗ {error_msg}")
        result['message'] = error_msg
        logging.info("")

    return result

def main():
    """Main execution function."""
    # Set up logging
    log_file = setup_logging()

    logging.info("=" * 70)
    logging.info("GitHub URL Clone and Python File Extraction")
    logging.info("Parallel Processing: Up to 4 repositories cloned simultaneously")
    logging.info("=" * 70)
    logging.info(f"Log file: {log_file.absolute()}")
    logging.info("")

    # Find latest CSV file
    csv_file = get_latest_csv()
    if not csv_file:
        return

    logging.info(f"Using CSV file: {csv_file.name}")
    logging.info(f"Location: {csv_file.absolute()}")
    logging.info("")

    # Create temp directories
    temp_dir = Path("temp")
    repos_dir = temp_dir / "repos"
    python_dir = temp_dir / "python_files"

    # Clean up existing temp directory
    if temp_dir.exists():
        logging.info("Cleaning up existing temp directory...")
        shutil.rmtree(temp_dir)
        logging.info("")

    repos_dir.mkdir(parents=True, exist_ok=True)
    python_dir.mkdir(parents=True, exist_ok=True)

    # Parse CSV and collect URLs for parallel processing
    url_tasks = []

    try:
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)

            for row in reader:
                url = row.get('URL', '').strip()
                subject = row.get('subject', '')

                if not url or 'github.com' not in url:
                    continue

                # Collect tasks for parallel processing
                url_tasks.append((url, subject))

    except Exception as e:
        logging.error(f"Error reading CSV file: {e}")
        return

    # Process URLs using multiprocessing with 4 workers
    total_urls = len(url_tasks)
    if total_urls == 0:
        logging.warning("No GitHub URLs found in CSV file")
        return

    logging.info(f"Processing {total_urls} URLs with 4 parallel workers...")
    logging.info("PARALLEL CLONING IN PROGRESS - Multiple repositories cloning simultaneously")
    logging.info("")

    # Prepare arguments for multiprocessing
    process_args = [
        (url, subject, repos_dir, python_dir, idx + 1, total_urls)
        for idx, (url, subject) in enumerate(url_tasks)
    ]

    results = {
        'total': total_urls,
        'successful': 0,
        'failed': 0,
        'python_files': 0,
        'details': []
    }

    # Use Pool with 4 workers to process URLs simultaneously
    logging.info("Starting parallel clone operations (up to 4 repositories at a time)...")
    with Pool(processes=4) as pool:
        processing_results = pool.map(process_single_url, process_args)

    logging.info("All parallel clone operations completed")
    logging.info("")

    # Aggregate results
    for result in processing_results:
        results['details'].append({
            'exercise': result['exercise'],
            'status': result['status'],
            'files': result['files'],
            'message': result['message']
        })

        if result['status'] == 'success':
            results['successful'] += 1
            results['python_files'] += result['files']
        else:
            results['failed'] += 1

    # Print summary
    logging.info("=" * 70)
    logging.info("SUMMARY")
    logging.info("=" * 70)
    logging.info(f"Total URLs processed: {results['total']}")
    logging.info(f"Successfully cloned: {results['successful']}")
    logging.info(f"Failed: {results['failed']}")
    logging.info(f"Total Python files extracted: {results['python_files']}")
    logging.info("")

    # Print detailed results
    if results['details']:
        logging.info("Detailed Results:")
        logging.info("-" * 70)
        for detail in results['details']:
            status_icon = "✓" if detail['status'] == 'success' else "✗"
            logging.info(f"{status_icon} {detail['exercise']:20s}: {detail['files']:2d} files - {detail['message']}")

    logging.info("")
    logging.info(f"Python files are located in: {python_dir.absolute()}")
    logging.info("=" * 70)

    # Run code analysis
    if results['successful'] > 0:
        logging.info("")
        logging.info("=" * 70)
        logging.info("STARTING CODE ANALYSIS")
        logging.info("=" * 70)
        logging.info("")

        # Get the script directory
        script_dir = Path(__file__).parent

        # Try to run analyze_code.py first (with Excel support)
        try:
            analyze_script = script_dir / "analyze_code.py"
            logging.info(f"Running {analyze_script.name}...")

            result = subprocess.run(
                ['python3', str(analyze_script)],
                capture_output=True,
                text=True,
                timeout=300
            )

            if result.returncode == 0:
                logging.info("✓ Code analysis completed successfully")
                if result.stdout:
                    print(result.stdout)
            else:
                # If analyze_code.py fails (likely due to missing pandas), try simple version
                if "pandas" in result.stderr or "ModuleNotFoundError" in result.stderr:
                    logging.warning("pandas not found, trying simple version...")

                    analyze_script_simple = script_dir / "analyze_code_simple.py"
                    result = subprocess.run(
                        ['python3', str(analyze_script_simple)],
                        capture_output=True,
                        text=True,
                        timeout=300
                    )

                    if result.returncode == 0:
                        logging.info("✓ Code analysis completed successfully (simple version)")
                        if result.stdout:
                            print(result.stdout)
                    else:
                        logging.error(f"✗ Code analysis failed: {result.stderr}")
                else:
                    logging.error(f"✗ Code analysis failed: {result.stderr}")

        except subprocess.TimeoutExpired:
            logging.error("Code analysis timed out (300s limit)")
        except Exception as e:
            logging.error(f"Error running code analysis: {e}")

if __name__ == "__main__":
    main()
