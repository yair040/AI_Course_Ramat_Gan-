#!/usr/bin/env python3
"""
Gmail Exercise Retrieval Script

Retrieves emails that match the following criteria:
- Subject starts with "self checking of exercise #"
- Located in the "exercises" label/folder

Outputs:
- CSV file with id, subject, date, URL, status columns
- Log file with operation details

Uses Gmail API with OAuth2 authentication.
"""

import sys
import os
import pickle
import csv
import re
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import base64

# Add parent directory to path to access credentials
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(os.path.dirname(SCRIPT_DIR))
FILES_DIR = os.path.join(PARENT_DIR, 'files')

# Gmail API Configuration
SCOPES = ['https://www.googleapis.com/auth/gmail.modify']
TOKEN_FILE = os.path.join(PARENT_DIR, 'token.pickle')
CREDENTIALS_FILE = os.path.join(PARENT_DIR, 'credentials.json')

# Logging
log_messages = []


def log(message):
    """Add message to log with timestamp"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = f"[{timestamp}] {message}"
    log_messages.append(log_entry)
    print(log_entry)


def authenticate_gmail(headless=False):
    """
    Authenticate with Gmail API using OAuth2

    Args:
        headless: If True, use manual code entry for servers without GUI

    Returns:
        Gmail API service object
    """
    creds = None

    # Load existing token if available
    if os.path.exists(TOKEN_FILE):
        log(f"Loading existing token from {TOKEN_FILE}...")
        with open(TOKEN_FILE, 'rb') as token:
            creds = pickle.load(token)

    # If no valid credentials available
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            log("Token expired. Refreshing...")
            creds.refresh(Request())
        else:
            # Check if credentials.json exists
            if not os.path.exists(CREDENTIALS_FILE):
                log(f"ERROR: {CREDENTIALS_FILE} not found!")
                print("Please download it from Google Cloud Console.")
                sys.exit(1)

            log("No valid token found. Starting authentication...")

            if headless:
                # Headless server authentication
                print("\n" + "="*60)
                print("HEADLESS AUTHENTICATION MODE")
                print("="*60)

                flow = InstalledAppFlow.from_client_secrets_file(
                    CREDENTIALS_FILE,
                    SCOPES,
                    redirect_uri='urn:ietf:wg:oauth:2.0:oob'
                )

                auth_url, _ = flow.authorization_url(prompt='consent')

                print("\nPlease visit this URL in ANY browser (phone/computer):")
                print(f"\n{auth_url}\n")
                print("After authorizing, you'll receive a code.")
                code = input("Enter the authorization code here: ").strip()

                flow.fetch_token(code=code)
                creds = flow.credentials
            else:
                # Local authentication with browser
                print("Opening browser for authentication...")
                flow = InstalledAppFlow.from_client_secrets_file(
                    CREDENTIALS_FILE, SCOPES)
                creds = flow.run_local_server(port=0)

        # Save the credentials for future use
        with open(TOKEN_FILE, 'wb') as token:
            pickle.dump(creds, token)
        log(f"Token saved to {TOKEN_FILE}")

    log("Authentication successful!")
    return build('gmail', 'v1', credentials=creds)


def get_header(headers, name):
    """Extract specific header value from email headers"""
    return next((h['value'] for h in headers if h['name'].lower() == name.lower()), '')


def get_email_body(payload):
    """
    Extract email body from payload

    Args:
        payload: Gmail message payload

    Returns:
        Email body as string
    """
    body = ''

    if 'body' in payload and 'data' in payload['body']:
        body = base64.urlsafe_b64decode(payload['body']['data']).decode('utf-8')
    elif 'parts' in payload:
        for part in payload['parts']:
            if part['mimeType'] == 'text/plain':
                if 'data' in part['body']:
                    body = base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                    break
            elif part['mimeType'] == 'text/html' and not body:
                if 'data' in part['body']:
                    body = base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')

    return body


def extract_github_url(body):
    """
    Extract GitHub URL from email body

    Args:
        body: Email body text

    Returns:
        GitHub URL string or "NOT_FOUND"
    """
    if not body:
        return "NOT_FOUND"

    # Pattern to match GitHub URLs
    github_pattern = r'https?://github\.com/[^\s<>\"\'\)]+(?:/pull/\d+|/issues/\d+|/commit/[a-f0-9]+)?'

    matches = re.findall(github_pattern, body, re.IGNORECASE)

    if not matches:
        return "NOT_FOUND"

    # Prioritize PR and issue links over general repo links
    for match in matches:
        if '/pull/' in match or '/issues/' in match or '/commit/' in match:
            return match

    # Return first match if no PR/issue found
    return matches[0]


def parse_email(message):
    """
    Parse Gmail message into structured format

    Args:
        message: Gmail API message object

    Returns:
        Dictionary with email details
    """
    headers = message['payload']['headers']

    email_data = {
        'id': message['id'],
        'thread_id': message['threadId'],
        'subject': get_header(headers, 'Subject'),
        'from': get_header(headers, 'From'),
        'to': get_header(headers, 'To'),
        'date': get_header(headers, 'Date'),
        'snippet': message.get('snippet', ''),
        'body': get_email_body(message['payload'])
    }

    return email_data


def retrieve_exercise_emails(service, max_results=50):
    """
    Retrieve emails matching the exercise criteria:
    - Subject starts with "self checking of exercise #"
    - Located in "exercises" label

    Args:
        service: Gmail API service object
        max_results: Maximum number of emails to retrieve

    Returns:
        List of parsed email dictionaries
    """
    try:
        # Gmail query: subject filter + label filter
        query = 'subject:"self checking of exercise #" label:exercises'

        log(f"Searching for emails with query: {query}")
        log(f"Maximum results: {max_results}")

        # Execute search
        results = service.users().messages().list(
            userId='me',
            q=query,
            maxResults=max_results
        ).execute()

        messages = results.get('messages', [])

        if not messages:
            log("No exercise emails found matching the criteria.")
            return []

        log(f"Found {len(messages)} exercise email(s). Retrieving details...")

        # Fetch and parse each message
        emails = []
        github_urls_found = 0

        for i, msg in enumerate(messages, 1):
            message = service.users().messages().get(
                userId='me',
                id=msg['id'],
                format='full'
            ).execute()

            email = parse_email(message)

            # Extract GitHub URL
            github_url = extract_github_url(email['body'])
            email['github_url'] = github_url

            if github_url != "NOT_FOUND":
                github_urls_found += 1
                log(f"Retrieved {i}/{len(messages)}: {email['subject'][:50]}... - URL found")
            else:
                log(f"Retrieved {i}/{len(messages)}: {email['subject'][:50]}... - No URL")

            emails.append(email)

        log(f"Extraction complete: {github_urls_found}/{len(messages)} emails had GitHub URLs")
        return emails

    except HttpError as error:
        log(f'Gmail API error: {error}')
        return []


def save_to_csv(emails, output_dir):
    """
    Save emails to CSV file with columns: id, subject, date, URL, status

    Args:
        emails: List of email dictionaries
        output_dir: Directory to save CSV file

    Returns:
        Path to created CSV file
    """
    if not emails:
        log("No emails to save to CSV")
        return None

    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Generate timestamp filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    csv_filename = f"gmail_extract_{timestamp}.csv"
    csv_filepath = os.path.join(output_dir, csv_filename)

    log(f"Creating CSV file: {csv_filepath}")

    try:
        with open(csv_filepath, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['id', 'subject', 'date', 'URL', 'status']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            # Write header
            writer.writeheader()

            # Write rows
            for i, email in enumerate(emails, 1):
                row = {
                    'id': i,
                    'subject': email['subject'],
                    'date': email['date'],
                    'URL': email['github_url'],
                    'status': 'done'
                }
                writer.writerow(row)

        log(f"CSV file created successfully: {csv_filename}")
        log(f"Total rows written: {len(emails)}")
        return csv_filepath

    except Exception as e:
        log(f"ERROR creating CSV file: {e}")
        return None


def save_log_file(output_dir):
    """
    Save log messages to log file

    Args:
        output_dir: Directory to save log file

    Returns:
        Path to created log file
    """
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Generate timestamp filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_filename = f"gmail_retrieve_log_{timestamp}.txt"
    log_filepath = os.path.join(output_dir, log_filename)

    try:
        with open(log_filepath, 'w', encoding='utf-8') as logfile:
            logfile.write("Gmail Exercise Retrieval Log\n")
            logfile.write("=" * 70 + "\n\n")
            for message in log_messages:
                logfile.write(message + "\n")

        return log_filepath

    except Exception as e:
        print(f"ERROR creating log file: {e}")
        return None


def main():
    """Main execution function"""
    log("Gmail Exercise Retrieval Tool")
    log("="*70)
    log("Retrieving emails where:")
    log("  - Subject starts with 'self checking of exercise #'")
    log("  - Located in 'exercises' label/folder")
    log("="*70)

    # Detect if running on headless server
    headless = not os.environ.get('DISPLAY')

    # Authenticate with Gmail
    service = authenticate_gmail(headless=headless)

    # Retrieve exercise emails
    emails = retrieve_exercise_emails(service, max_results=50)

    # Save to CSV
    csv_file = save_to_csv(emails, FILES_DIR)

    # Save log file
    log_file = save_log_file(FILES_DIR)

    # Final summary
    print("\n" + "="*70)
    print("RETRIEVAL COMPLETE")
    print("="*70)
    print(f"Total emails retrieved: {len(emails)}")

    if csv_file:
        print(f"\nCSV output file: {csv_file}")

    if log_file:
        print(f"Log file: {log_file}")

    print("="*70)


if __name__ == '__main__':
    main()
