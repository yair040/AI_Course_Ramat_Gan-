# Gmail Exercise Retrieval Skill

You are a specialized skill for retrieving emails from Gmail that match specific criteria related to course exercises.

## Task

Retrieve and display emails that meet ALL of the following criteria:
1. Subject line starts with "self checking of exercise #"
2. Located in the "exercises" label/folder
3. Parse and present the email details in a clear, structured format

## Implementation Instructions

1. **Authentication**
   - Use the existing `gmail_client.py` module in the parent directory
   - Import and call `authenticate_gmail()` function which handles OAuth2 authentication
   - This function uses credentials from `credentials.json` and `token.pickle` (DO NOT expose these credentials in output)
   - The authentication is already set up with scope: `https://www.googleapis.com/auth/gmail.modify`

2. **Email Retrieval**
   - Use the Gmail API service to search for messages with the following query:
     ```
     subject:"self checking of exercise #" label:exercises
     ```
   - This query filters emails where:
     - Subject starts with "self checking of exercise #"
     - Email is labeled with "exercises"

3. **Email Processing**
   - Use the `parse_email()` function from `gmail_client.py` to parse each message
   - Extract the following information for each email:
     - Subject
     - From (sender)
     - Date
     - Snippet (preview)
     - Full body text
     - Message ID

4. **Output Format**
   - Present results in a clear, numbered list
   - For each email show:
     - Exercise number (extracted from subject)
     - Sender
     - Date received
     - Preview/snippet
     - Option to view full body
   - If no matching emails found, report that clearly

## Python Implementation Example

```python
import sys
import os

# Add parent directory to path to import gmail_client
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from gmail_client import authenticate_gmail, parse_email
from googleapiclient.errors import HttpError

# Authenticate
service = authenticate_gmail(headless=True)

# Search for exercise emails in the exercises folder
try:
    query = 'subject:"self checking of exercise #" label:exercises'
    results = service.users().messages().list(
        userId='me',
        q=query,
        maxResults=50
    ).execute()

    messages = results.get('messages', [])

    if not messages:
        print("No exercise emails found matching the criteria.")
    else:
        print(f"Found {len(messages)} exercise email(s):\n")

        for i, msg in enumerate(messages, 1):
            # Get full message details
            message = service.users().messages().get(
                userId='me',
                id=msg['id'],
                format='full'
            ).execute()

            # Parse the email
            email = parse_email(message)

            # Display formatted output
            print(f"{'='*60}")
            print(f"Email #{i}")
            print(f"{'='*60}")
            print(f"Subject: {email['subject']}")
            print(f"From: {email['from']}")
            print(f"Date: {email['date']}")
            print(f"Preview: {email['snippet'][:150]}...")
            print(f"\nMessage ID: {email['id']}")
            print()

except HttpError as error:
    print(f'An error occurred: {error}')
```

## Security Notes

- Credentials are stored securely in `credentials.json` and `token.pickle`
- NEVER display or print the contents of these credential files
- The OAuth2 flow handles authentication securely through Google's servers
- Only display email content and metadata, never authentication tokens or secrets

## Usage

When invoked, this skill will:
1. Silently authenticate using existing credentials
2. Query Gmail for matching exercise emails
3. Display results in a user-friendly format
4. Handle errors gracefully (e.g., no matching emails, API errors)

The user can then review the exercise emails and their contents without needing to manually search through their Gmail inbox.
