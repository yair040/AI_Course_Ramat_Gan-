# Installation Guide
**Exercise Checking System v1.0.0**

---

## Prerequisites

Before installing, ensure you have:

- ✓ Python 3.8 or higher
- ✓ WSL (Windows Subsystem for Linux) or Linux OS
- ✓ Gmail API credentials (`credentials.json`)
- ✓ Internet connection
- ✓ Approximately 500MB free disk space

---

## Step-by-Step Installation

### Step 1: Extract Package

Extract the package to your desired location:

```bash
# Example location
cd ~/Documents
tar -xzf exercise_checking_system_v1.0.0.tar.gz
cd exercise_checking_system_package
```

Or if you have a zip file:
```bash
unzip exercise_checking_system_v1.0.0.zip
cd exercise_checking_system_package
```

---

### Step 2: Obtain Gmail API Credentials

**IMPORTANT:** You must have Gmail API credentials to use this system.

#### Option A: If you already have credentials.json
1. Copy your `credentials.json` file to the package directory:
   ```bash
   cp /path/to/your/credentials.json .
   ```

#### Option B: Create new credentials
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing project
3. Enable Gmail API:
   - Navigate to "APIs & Services" → "Library"
   - Search for "Gmail API"
   - Click "Enable"
4. Create credentials:
   - Go to "APIs & Services" → "Credentials"
   - Click "Create Credentials" → "OAuth client ID"
   - Select "Desktop app" as application type
   - Download the JSON file
   - Rename it to `credentials.json`
   - Place it in the package directory

---

### Step 3: Run Setup Script

The setup script will automatically:
- Create a virtual environment
- Install all required Python packages
- Set up directory structure

```bash
# Make the script executable
chmod +x setup.sh

# Run the setup
./setup.sh
```

Expected output:
```
========================================
Exercise Checking System - Setup
========================================

Checking Python version...
Python 3.x.x
✓ Python 3 found

Creating virtual environment...
✓ Virtual environment created

Activating virtual environment...
✓ Virtual environment activated

Installing dependencies from requirements.txt...
✓ Dependencies installed

Creating directories...
✓ Directories created

✓ credentials.json found

========================================
Setup completed successfully!
========================================
```

---

### Step 4: Verify Installation

Activate the virtual environment and test:

```bash
# Activate virtual environment
source venv/bin/activate

# Verify Python packages
pip list | grep google

# Test the application
python3 main.py
```

You should see the main menu:
```
============================================================
EXERCISE CHECKING SYSTEM
============================================================

1. Run Agent 1: gmail_retrieve
2. Run Agent 2: mail-code-analyzer
3. Run Agent 3: greeting-style-generator
4. Run Agent 4: gmail-draft-sender
5. Run Pipeline: Execute all agents in sequence
6. Reset: Clean up files and temp directories
0. Exit

============================================================
```

---

### Step 5: First-Time Gmail Authentication

The first time you run an agent that accesses Gmail:

1. Select option 1 (gmail_retrieve) or option 5 (pipeline)
2. A browser window will open
3. Log in to your Google account
4. Grant the requested permissions
5. A `token.pickle` file will be created automatically
6. Future runs will use this token (no need to authenticate again)

---

## Manual Installation (Alternative)

If the setup script doesn't work, follow these manual steps:

### 1. Create Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install Dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Create Directories
```bash
mkdir -p log files temp
```

### 4. Add Credentials
```bash
# Place your credentials.json in the package root
cp /path/to/credentials.json .
```

### 5. Test Installation
```bash
python3 main.py
```

---

## Troubleshooting Installation

### Issue: Python 3 not found

**Error:** `bash: python3: command not found`

**Solution:**
```bash
# On Ubuntu/Debian
sudo apt update
sudo apt install python3 python3-pip python3-venv

# On WSL
sudo apt update && sudo apt upgrade
sudo apt install python3 python3-pip python3-venv
```

---

### Issue: Virtual environment creation fails

**Error:** `The virtual environment was not created successfully`

**Solution:**
```bash
# Install venv package
sudo apt install python3-venv

# Try again
python3 -m venv venv
```

---

### Issue: Permission denied on setup.sh

**Error:** `bash: ./setup.sh: Permission denied`

**Solution:**
```bash
chmod +x setup.sh
./setup.sh
```

---

### Issue: pip install fails

**Error:** Various pip installation errors

**Solution:**
```bash
# Upgrade pip
pip install --upgrade pip

# Install packages one by one to identify the problem
pip install google-auth
pip install google-auth-oauthlib
pip install google-api-python-client
# ... continue with other packages from requirements.txt
```

---

### Issue: credentials.json not found

**Error:** `⚠ Warning: credentials.json not found`

**Solution:**
1. Ensure `credentials.json` is in the package root directory
2. Check the filename (must be exactly `credentials.json`)
3. Verify the file is not empty
4. See Step 2 above for obtaining credentials

---

### Issue: Import errors when running

**Error:** `ModuleNotFoundError: No module named 'google'`

**Solution:**
```bash
# Make sure virtual environment is activated
source venv/bin/activate

# Reinstall requirements
pip install -r requirements.txt

# Verify installation
pip list
```

---

## Post-Installation Configuration

### Optional: Customize Configuration

Edit `config.json` to customize:

```json
{
  "system": {
    "log_level": "INFO",    // Change to "DEBUG" for more details
    "max_log_file_size_mb": 16,
    "max_log_files": 20
  },
  "agents": {
    "gmail_retrieve": {
      "timeout_seconds": 300  // Increase if needed
    }
  }
}
```

### Optional: Test with Sample Data

Before processing real submissions:

1. Create test emails in Gmail
2. Run individual agents to test
3. Check log files in `log/` directory
4. Verify CSV outputs in `files/` directory

---

## Verifying Successful Installation

Run this checklist to ensure everything is working:

- [ ] `python3 --version` shows 3.8 or higher
- [ ] Virtual environment created: `venv/` directory exists
- [ ] Virtual environment activated: `(venv)` appears in prompt
- [ ] All packages installed: `pip list` shows google packages
- [ ] Directories created: `log/`, `files/`, `temp/` exist
- [ ] `credentials.json` exists in package root
- [ ] `python3 main.py` shows the menu
- [ ] Can select menu options without errors
- [ ] Log files created in `log/` directory

---

## Uninstallation

To completely remove the system:

```bash
# Deactivate virtual environment if active
deactivate

# Remove the entire directory
cd ..
rm -rf exercise_checking_system_package

# Note: This will delete all data including:
# - Log files
# - CSV outputs
# - Temporary files
# - Configuration changes
```

**Important:** Backup any important data before uninstalling!

---

## Getting Help

If installation fails:

1. Check this guide's troubleshooting section
2. Review `README.md` for usage information
3. Check `tasks.md` for common issues
4. Review installation logs for specific errors
5. Ensure all prerequisites are met

---

## Next Steps

After successful installation:

1. Read `README.md` for usage instructions
2. Review `PRD.md` to understand the system
3. Check `Claude.md` for agent details
4. Test with sample data before production use

---

**Installation Guide Version:** 1.0.0
**Last Updated:** 2025-11-25
**Support:** See README.md
