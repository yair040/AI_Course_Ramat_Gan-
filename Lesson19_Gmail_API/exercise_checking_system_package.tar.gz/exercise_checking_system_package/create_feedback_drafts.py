#!/usr/bin/env python3
"""
Combine data from CSV files and create Gmail drafts for student feedback
"""
import os
import sys
import csv

# Add skills directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'skills', 'send_draft'))
from send_draft import send_to_draft


def read_csv_to_dict(csv_file):
    """
    Read a CSV file and return a list of dictionaries, indexed by 'id'

    Args:
        csv_file: Path to CSV file

    Returns:
        Dictionary with id as key and row data as value
    """
    data_dict = {}
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            row_id = int(row['id'])
            data_dict[row_id] = row
    return data_dict


def load_csv_files(files_dir='./files'):
    """
    Load all three CSV files: gmail_extract, personalized_greetings, and code_analysis_report

    Returns:
        tuple of (emails_dict, greetings_dict, grades_dict)
    """
    # Find the latest CSV files
    gmail_file = None
    greetings_file = None
    grades_file = None

    for file in os.listdir(files_dir):
        if file.startswith('gmail_extract_') and file.endswith('.csv'):
            gmail_file = os.path.join(files_dir, file)
        elif file.startswith('personalized_greetings_') and file.endswith('.csv'):
            greetings_file = os.path.join(files_dir, file)
        elif file.startswith('code_analysis_report_') and file.endswith('.csv'):
            # Get the latest grades file
            file_path = os.path.join(files_dir, file)
            if grades_file is None or os.path.getmtime(file_path) > os.path.getmtime(grades_file):
                grades_file = file_path

    print(f"Loading files:")
    print(f"  Gmail extract: {gmail_file}")
    print(f"  Greetings: {greetings_file}")
    print(f"  Grades: {grades_file}")

    if not all([gmail_file, greetings_file, grades_file]):
        raise FileNotFoundError("Could not find all required CSV files")

    # Load the CSV files
    emails_dict = read_csv_to_dict(gmail_file)
    greetings_dict = read_csv_to_dict(greetings_file)
    grades_dict = read_csv_to_dict(grades_file)

    return emails_dict, greetings_dict, grades_dict


def extract_recipient_email(subject):
    """
    Extract recipient email from subject or use a default
    For now, using yair040@gmail.com as specified
    """
    return "yair040@gmail.com"


def extract_exercise_number(subject):
    """
    Extract exercise number from subject like "self checking of exercise #9"
    """
    import re
    match = re.search(r'#(\d+)', subject)
    if match:
        return match.group(1)
    return "Unknown"


def combine_feedback_data(emails_dict, greetings_dict, grades_dict):
    """
    Combine data from all three dictionaries based on ID

    Returns:
        List of dictionaries with combined feedback data
    """
    feedback_list = []

    # Get all IDs from emails (assuming all CSVs have the same IDs)
    for id_key in sorted(emails_dict.keys()):
        email_row = emails_dict[id_key]
        greeting_row = greetings_dict.get(id_key)
        grade_row = grades_dict.get(id_key)

        if not greeting_row or not grade_row:
            print(f"Warning: Missing data for ID {id_key}, skipping...")
            continue

        exercise_num = extract_exercise_number(email_row['subject'])

        feedback = {
            'id': id_key,
            'recipient_email': extract_recipient_email(email_row['subject']),
            'recipient_name': 'Student',  # Could be extracted from somewhere if available
            'subject': f"Feedback on Exercise #{exercise_num}",
            'url': email_row['URL'],
            'greeting': greeting_row['greeting'],
            'grade': grade_row['grade'],
            'exercise_number': exercise_num
        }

        # Create the email body with greeting and grade
        feedback['body'] = f"""{feedback['greeting']}

Your grade for Exercise #{exercise_num}: {feedback['grade']}

Please review your submission at the URL above and feel free to reach out if you have any questions.
"""

        feedback_list.append(feedback)

    return feedback_list


def create_drafts(feedback_list):
    """
    Create Gmail drafts for each feedback entry

    Args:
        feedback_list: List of feedback dictionaries

    Returns:
        List of created draft IDs
    """
    draft_ids = []

    print(f"\n{'='*60}")
    print(f"Creating {len(feedback_list)} Gmail drafts...")
    print(f"{'='*60}\n")

    for i, feedback in enumerate(feedback_list, 1):
        print(f"[{i}/{len(feedback_list)}] Creating draft for Exercise #{feedback['exercise_number']}...")
        print(f"  Recipient: {feedback['recipient_email']}")
        print(f"  Subject: {feedback['subject']}")
        print(f"  Grade: {feedback['grade']}")
        print(f"  URL: {feedback['url']}")

        draft_id = send_to_draft(
            email_address=feedback['recipient_email'],
            subject=feedback['subject'],
            url=feedback['url'],
            text_to_send=feedback['body'],
            recipient_name=feedback['recipient_name']
        )

        if draft_id:
            print(f"  ✅ Draft created successfully (ID: {draft_id})\n")
            draft_ids.append(draft_id)
        else:
            print(f"  ❌ Failed to create draft\n")

    return draft_ids


def main():
    """
    Main function to orchestrate the feedback draft creation process
    """
    try:
        # Step 1: Load CSV files
        print("Step 1: Loading CSV files...")
        emails_dict, greetings_dict, grades_dict = load_csv_files()
        print(f"  ✅ Loaded {len(emails_dict)} emails, {len(greetings_dict)} greetings, {len(grades_dict)} grades\n")

        # Step 2: Combine data
        print("Step 2: Combining feedback data...")
        feedback_list = combine_feedback_data(emails_dict, greetings_dict, grades_dict)
        print(f"  ✅ Created {len(feedback_list)} feedback entries\n")

        # Step 3: Create drafts
        print("Step 3: Creating Gmail drafts...")
        draft_ids = create_drafts(feedback_list)

        # Step 4: Summary
        print(f"\n{'='*60}")
        print(f"SUMMARY")
        print(f"{'='*60}")
        print(f"Total feedback entries: {len(feedback_list)}")
        print(f"Drafts created successfully: {len(draft_ids)}")
        print(f"Failed: {len(feedback_list) - len(draft_ids)}")
        print(f"{'='*60}\n")

        if len(draft_ids) == len(feedback_list):
            print("✅ All drafts created successfully!")
        else:
            print("⚠️  Some drafts failed. Check the log file for details.")

        return len(draft_ids) == len(feedback_list)

    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
