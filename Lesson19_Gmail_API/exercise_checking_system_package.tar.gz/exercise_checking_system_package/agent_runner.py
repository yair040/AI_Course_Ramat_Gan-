"""
Agent Runner Module
Handles execution of individual agents and monitors their status
"""

import subprocess
import time
import csv
from pathlib import Path
from exercise_checking_system_package.log_config import get_agent_logger


class AgentRunner:
    """Manages agent execution and status monitoring."""

    BASE_DIR = Path(__file__).parent
    FILES_DIR = BASE_DIR / "files"
    TEMP_DIR = BASE_DIR / "temp"
    SKILLS_DIR = BASE_DIR / "skills"

    AGENTS = {
        "gmail_retrieve": {
            "script": SKILLS_DIR / "gmail" / "email_retrieve.py",
            "output_pattern": "gmail_extract",
            "description": "Retrieve emails from Gmail"
        },
        "mail-code-analyzer": {
            "script": SKILLS_DIR / "url" / "clone_and_extract.py",
            "output_pattern": "code_analysis_report",
            "description": "Analyze code from GitHub URLs"
        },
        "greeting-style-generator": {
            "script": SKILLS_DIR / "style" / "generate_greetings.py",
            "output_pattern": "personalized_greetings",
            "description": "Generate personalized greetings"
        },
        "gmail-draft-sender": {
            "script": BASE_DIR / "create_feedback_drafts.py",
            "output_pattern": None,
            "description": "Send draft emails via Gmail"
        }
    }

    def __init__(self, agent_name):
        """
        Initialize agent runner.

        Args:
            agent_name: Name of the agent to run
        """
        self.agent_name = agent_name
        self.logger = get_agent_logger(agent_name)
        self.agent_config = self.AGENTS.get(agent_name)

        if not self.agent_config:
            raise ValueError(f"Unknown agent: {agent_name}")

        # Ensure directories exist
        self.FILES_DIR.mkdir(exist_ok=True)
        self.TEMP_DIR.mkdir(exist_ok=True)

    def run(self):
        """
        Execute the agent.

        Returns:
            bool: True if successful, False otherwise
        """
        self.logger.info(f"Starting agent: {self.agent_name}")
        self.logger.info(f"Description: {self.agent_config['description']}")

        try:
            script_path = self.agent_config['script']

            if script_path is None:
                # Agent uses Claude CLI
                return self._run_claude_agent()
            else:
                # Agent uses Python script
                return self._run_python_script(script_path)

        except Exception as e:
            self.logger.error(f"Agent execution failed: {e}", exc_info=True)
            return False

    def _run_python_script(self, script_path):
        """Run a Python script-based agent."""
        if not script_path.exists():
            self.logger.error(f"Script not found: {script_path}")
            return False

        self.logger.info(f"Executing script: {script_path}")

        try:
            result = subprocess.run(
                ["python3", str(script_path)],
                cwd=str(self.BASE_DIR),
                capture_output=True,
                text=True,
                timeout=300
            )

            if result.stdout:
                self.logger.info(f"Output: {result.stdout}")
            if result.stderr:
                self.logger.warning(f"Errors: {result.stderr}")

            if result.returncode == 0:
                self.logger.info(f"Agent {self.agent_name} completed successfully")
                return True
            else:
                self.logger.error(
                    f"Agent {self.agent_name} failed with return code {result.returncode}"
                )
                return False

        except subprocess.TimeoutExpired:
            self.logger.error("Agent execution timed out")
            return False
        except Exception as e:
            self.logger.error(f"Error running script: {e}", exc_info=True)
            return False

    def _run_claude_agent(self):
        """Run a Claude CLI-based agent."""
        self.logger.info(f"Claude agent {self.agent_name} requires manual execution")
        self.logger.info("Please run the agent using Claude CLI")
        return False

    def check_status(self, timeout=300, poll_interval=5):
        """
        Monitor agent output and wait for completion.

        Args:
            timeout: Maximum time to wait in seconds
            poll_interval: Time between status checks

        Returns:
            bool: True if agent completed successfully
        """
        output_pattern = self.agent_config.get('output_pattern')
        if not output_pattern:
            self.logger.info("No output file to monitor")
            return True

        self.logger.info(f"Monitoring for completion (pattern: {output_pattern})")

        start_time = time.time()
        while time.time() - start_time < timeout:
            output_file = self._find_latest_output(output_pattern)

            if output_file and self._check_done_status(output_file):
                self.logger.info(f"Agent completed: {output_file.name}")
                return True

            time.sleep(poll_interval)

        self.logger.warning("Timeout waiting for agent completion")
        return False

    def _find_latest_output(self, pattern):
        """Find the latest output file matching the pattern."""
        matching_files = list(self.FILES_DIR.glob(f"*{pattern}*.csv"))
        if not matching_files:
            return None
        return max(matching_files, key=lambda p: p.stat().st_mtime)

    def _check_done_status(self, csv_file):
        """Check if all rows in CSV have status='done'."""
        try:
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)

                if not rows:
                    return False

                for row in rows:
                    if row.get('status', '').lower() != 'done':
                        return False

                return True
        except Exception as e:
            self.logger.error(f"Error checking status: {e}")
            return False


def run_agent(agent_name, wait_for_completion=True):
    """
    Convenience function to run an agent.

    Args:
        agent_name: Name of the agent
        wait_for_completion: Wait for agent to complete

    Returns:
        bool: True if successful
    """
    runner = AgentRunner(agent_name)
    success = runner.run()

    if success and wait_for_completion:
        return runner.check_status()

    return success
