#!/usr/bin/env python3
"""
Exercise Checking System - Main Program
Author: Yair Levi

Main menu interface for running individual agents or complete pipeline.
"""

import sys
import shutil
from pathlib import Path
from exercise_checking_system_package.log_config import get_main_logger
from exercise_checking_system_package.agent_runner import AgentRunner


class ExerciseCheckingSystem:
    """Main application controller."""

    BASE_DIR = Path(__file__).parent
    FILES_DIR = BASE_DIR / "files"
    TEMP_DIR = BASE_DIR / "temp"
    LOG_DIR = BASE_DIR / "log"

    def __init__(self):
        """Initialize the system."""
        self.logger = get_main_logger()
        self.logger.info("=" * 60)
        self.logger.info("Exercise Checking System Started")
        self.logger.info("=" * 60)

        # Ensure directories exist
        self.FILES_DIR.mkdir(exist_ok=True)
        self.TEMP_DIR.mkdir(exist_ok=True)

    def display_menu(self):
        """Display the main menu."""
        print("\n" + "=" * 60)
        print("EXERCISE CHECKING SYSTEM")
        print("=" * 60)
        print("\n1. Run Agent 1: gmail_retrieve")
        print("2. Run Agent 2: mail-code-analyzer")
        print("3. Run Agent 3: greeting-style-generator")
        print("4. Run Agent 4: gmail-draft-sender")
        print("5. Run Pipeline: Execute all agents in sequence")
        print("6. Reset: Clean up files and temp directories")
        print("0. Exit")
        print("\n" + "=" * 60)

    def run_single_agent(self, agent_name):
        """
        Run a single agent.

        Args:
            agent_name: Name of the agent to run

        Returns:
            bool: True if successful
        """
        self.logger.info(f"User selected: Run agent '{agent_name}'")
        print(f"\n>>> Running agent: {agent_name}")

        try:
            runner = AgentRunner(agent_name)
            success = runner.run()

            if success:
                print(f"✓ Agent {agent_name} executed successfully")
                self.logger.info(f"Agent {agent_name} completed successfully")

                # Wait for completion if agent has output
                if runner.agent_config.get('output_pattern'):
                    print(f">>> Waiting for agent to complete...")
                    if runner.check_status(timeout=300):
                        print(f"✓ Agent {agent_name} completed with status='done'")
                        return True
                    else:
                        print(f"⚠ Agent {agent_name} did not complete in time")
                        return False
                return True
            else:
                print(f"✗ Agent {agent_name} execution failed")
                self.logger.error(f"Agent {agent_name} failed")
                return False

        except Exception as e:
            print(f"✗ Error running agent: {e}")
            self.logger.error(f"Error running agent {agent_name}: {e}", exc_info=True)
            return False

    def run_pipeline(self):
        """
        Run all agents in sequence with status checking.

        Returns:
            bool: True if entire pipeline succeeds
        """
        self.logger.info("User selected: Run full pipeline")
        print("\n>>> Starting pipeline execution")
        print("=" * 60)

        agents = [
            "gmail_retrieve",
            "mail-code-analyzer",
            "greeting-style-generator",
            "gmail-draft-sender"
        ]

        for idx, agent_name in enumerate(agents, 1):
            print(f"\n[{idx}/{len(agents)}] Running agent: {agent_name}")
            self.logger.info(f"Pipeline step {idx}/{len(agents)}: {agent_name}")

            try:
                runner = AgentRunner(agent_name)
                success = runner.run()

                if not success:
                    print(f"✗ Agent {agent_name} failed to execute")
                    self.logger.error(f"Pipeline failed at agent {agent_name}")
                    return False

                # Wait for completion before starting next agent
                if runner.agent_config.get('output_pattern'):
                    print(f">>> Waiting for agent to complete...")
                    if not runner.check_status(timeout=600):
                        print(f"✗ Agent {agent_name} did not complete")
                        self.logger.error(
                            f"Pipeline failed: {agent_name} timeout"
                        )
                        return False

                print(f"✓ Agent {agent_name} completed successfully")

            except Exception as e:
                print(f"✗ Error in pipeline at {agent_name}: {e}")
                self.logger.error(
                    f"Pipeline error at {agent_name}: {e}",
                    exc_info=True
                )
                return False

        print("\n" + "=" * 60)
        print("✓ Pipeline completed successfully!")
        self.logger.info("Pipeline completed successfully")
        return True

    def reset_system(self):
        """Clean up files, temp, and log directories."""
        self.logger.info("User selected: Reset system")
        print("\n>>> Resetting system...")

        try:
            # Clean files directory
            if self.FILES_DIR.exists():
                for item in self.FILES_DIR.iterdir():
                    if item.is_file():
                        item.unlink()
                        self.logger.info(f"Deleted file: {item.name}")
                    elif item.is_dir():
                        shutil.rmtree(item)
                        self.logger.info(f"Deleted directory: {item.name}")
                print(f"✓ Cleaned {self.FILES_DIR}")

            # Clean temp directory
            if self.TEMP_DIR.exists():
                for item in self.TEMP_DIR.iterdir():
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item)
                print(f"✓ Cleaned {self.TEMP_DIR}")

            # Clean log directory
            if self.LOG_DIR.exists():
                for item in self.LOG_DIR.iterdir():
                    if item.is_file():
                        item.unlink()
                    elif item.is_dir():
                        shutil.rmtree(item)
                print(f"✓ Cleaned {self.LOG_DIR}")

            print("✓ System reset completed")
            self.logger.info("System reset completed successfully")
            return True

        except Exception as e:
            print(f"✗ Error during reset: {e}")
            self.logger.error(f"Reset failed: {e}", exc_info=True)
            return False

    def run(self):
        """Main application loop."""
        while True:
            try:
                self.display_menu()
                choice = input("\nEnter your choice (0-6): ").strip()

                if choice == "0":
                    print("\nExiting... Goodbye!")
                    self.logger.info("User exited application")
                    break

                elif choice == "1":
                    self.run_single_agent("gmail_retrieve")

                elif choice == "2":
                    self.run_single_agent("mail-code-analyzer")

                elif choice == "3":
                    self.run_single_agent("greeting-style-generator")

                elif choice == "4":
                    self.run_single_agent("gmail-draft-sender")

                elif choice == "5":
                    self.run_pipeline()

                elif choice == "6":
                    confirm = input(
                        "Are you sure you want to reset? (yes/no): "
                    ).strip().lower()
                    if confirm == "yes":
                        self.reset_system()
                    else:
                        print("Reset cancelled")

                else:
                    print("Invalid choice. Please enter 0-6.")

                input("\nPress Enter to continue...")

            except KeyboardInterrupt:
                print("\n\nInterrupted by user. Exiting...")
                self.logger.info("Application interrupted by user")
                break
            except Exception as e:
                print(f"\nError: {e}")
                self.logger.error(f"Unexpected error: {e}", exc_info=True)
                input("\nPress Enter to continue...")


def main():
    """Entry point for the application."""
    try:
        app = ExerciseCheckingSystem()
        app.run()
    except Exception as e:
        print(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
