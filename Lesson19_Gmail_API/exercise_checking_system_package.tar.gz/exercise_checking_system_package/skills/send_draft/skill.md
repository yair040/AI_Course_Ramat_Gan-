# Gmail Draft Sender Skill

This skill creates draft emails in Gmail using the Gmail API. It constructs personalized email drafts with URLs and custom text, then saves them to the Gmail drafts folder.

## Purpose

Automate the creation of Gmail draft emails with structured content including:
- Personalized recipient email addresses
- Custom subjects
- URL references formatted as clickable links
- Custom message text
- Recipient names for personalization

## Input Parameters

When invoked, this skill requires the following inputs:

1. **email_address** - The recipient's email address
2. **subject** - The email subject line
3. **url** - A URL to reference in the email (will be formatted as a clickable link)
4. **text_to_send** - The main body text/message content
5. **recipient_name** - The recipient's name for personalization

## Email Structure

Each draft email will be formatted as follows:

```
To: [email_address]
Subject: [subject]

Dear [recipient_name],

Regarding the [URL as clickable hyperlink]

[text_to_send]

Best regards
```

## Gmail API Setup

### Credentials Location
- Credentials file: `credentials.json` (located in the current working directory)
- Token file: `token.pickle` (created after first authentication, stores access tokens)

### Required Python Libraries
```python
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import base64
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging
import os
import pickle
```

### Gmail API Scopes
Use the following scope for draft creation:
```python
SCOPES = ['https://www.googleapis.com/auth/gmail.compose']
```

## Implementation Instructions

### 1. Authentication Flow

```python
def authenticate_gmail():
    """Authenticate with Gmail API using credentials.json"""
    creds = None

    # Check if token.pickle exists (stores user's access and refresh tokens)
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # If no valid credentials, let user log in
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        # Save credentials for next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    return build('gmail', 'v1', credentials=creds)
```

### 2. Email Message Construction

```python
def create_draft_message(to_email, subject, url, text_content, recipient_name):
    """Create a properly formatted email message with HTML for clickable links"""

    # Create message container with both plain text and HTML versions
    message = MIMEMultipart('alternative')
    message['To'] = to_email
    message['Subject'] = subject

    # Plain text version
    text_body = f"""Dear {recipient_name},

Regarding the {url}

{text_content}

Best regards"""

    # HTML version with clickable link
    html_body = f"""<html>
  <body>
    <p>Dear {recipient_name},</p>
    <p>Regarding the <a href="{url}">{url}</a></p>
    <p>{text_content}</p>
    <p>Best regards</p>
  </body>
</html>"""

    # Attach both versions
    part1 = MIMEText(text_body, 'plain')
    part2 = MIMEText(html_body, 'html')
    message.attach(part1)
    message.attach(part2)

    # Encode message
    raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
    return {'message': {'raw': raw_message}}
```

### 3. Create Draft in Gmail

```python
def create_gmail_draft(service, draft_message):
    """Create a draft email in Gmail"""
    try:
        draft = service.users().drafts().create(
            userId='me',
            body=draft_message
        ).execute()

        return draft
    except HttpError as error:
        logging.error(f'An error occurred creating draft: {error}')
        raise
```

### 4. Main Workflow

```python
def send_to_draft(email_address, subject, url, text_to_send, recipient_name):
    """
    Main function to create a Gmail draft

    Args:
        email_address: Recipient email address
        subject: Email subject line
        url: URL to reference in email body
        text_to_send: Main message text
        recipient_name: Recipient's name

    Returns:
        Draft ID if successful, None otherwise
    """
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('./files/gmail_draft_log.txt'),
            logging.StreamHandler()
        ]
    )

    logging.info(f"Starting draft creation for recipient: {recipient_name}")
    logging.info(f"Subject: {subject}")
    logging.info(f"URL: {url}")

    try:
        # Authenticate
        logging.info("Authenticating with Gmail API...")
        service = authenticate_gmail()
        logging.info("Authentication successful")

        # Create message
        logging.info("Creating email message...")
        draft_message = create_draft_message(
            email_address,
            subject,
            url,
            text_to_send,
            recipient_name
        )

        # Create draft
        logging.info("Creating draft in Gmail...")
        draft = create_gmail_draft(service, draft_message)

        draft_id = draft['id']
        logging.info(f"Draft created successfully! Draft ID: {draft_id}")
        logging.info(f"Recipient: {email_address}")

        return draft_id

    except Exception as e:
        logging.error(f"Error creating draft: {str(e)}")
        return None
```

## Security Considerations

**CRITICAL SECURITY RULES:**

1. **NEVER log or print credentials.json contents**
2. **NEVER expose access tokens or refresh tokens**
3. **NEVER include credentials in error messages**
4. **DO NOT commit credentials.json or token.pickle to version control**
5. Only log:
   - Recipient email addresses (non-sensitive)
   - Subject lines
   - URLs
   - Success/failure status
   - Draft IDs
   - Timestamps

### Safe Logging Examples:

✅ **Safe:**
```python
logging.info(f"Draft created for: user@example.com")
logging.info(f"Subject: Meeting Follow-up")
logging.info(f"Draft ID: draft_abc123")
```

❌ **UNSAFE - NEVER DO THIS:**
```python
logging.info(f"Credentials: {creds}")  # NEVER
logging.info(f"Token: {token}")  # NEVER
```

## Error Handling

Implement comprehensive error handling for:

1. **Missing credentials.json**
   - Log error clearly
   - Provide guidance to user

2. **Authentication failures**
   - Log error without exposing credentials
   - Suggest re-authentication

3. **API quota exceeded**
   - Log rate limit error
   - Suggest retry timing

4. **Invalid email addresses**
   - Validate email format before API call
   - Log validation errors

5. **Network errors**
   - Log connection issues
   - Implement retry logic for transient failures

## Usage Example

When invoked, the skill should be called like this:

```python
draft_id = send_to_draft(
    email_address="student@example.com",
    subject="Exercise 18 Feedback",
    url="https://github.com/username/repo/pull/123",
    text_to_send="Great work on your submission! I've reviewed your code and have some feedback...",
    recipient_name="John"
)
```

## Output

The skill should:

1. Create a draft in Gmail with the formatted content
2. Return the draft ID upon success
3. Log all operations to `./files/gmail_draft_log.txt`
4. Display success/failure status to the user
5. NEVER expose sensitive credential information

## Logging Format

Log entries should follow this format:

```
2024-11-24 21:30:00 - INFO - Starting draft creation for recipient: John
2024-11-24 21:30:00 - INFO - Subject: Exercise 18 Feedback
2024-11-24 21:30:00 - INFO - URL: https://github.com/username/repo/pull/123
2024-11-24 21:30:01 - INFO - Authenticating with Gmail API...
2024-11-24 21:30:02 - INFO - Authentication successful
2024-11-24 21:30:02 - INFO - Creating email message...
2024-11-24 21:30:02 - INFO - Creating draft in Gmail...
2024-11-24 21:30:03 - INFO - Draft created successfully! Draft ID: draft_r123456789
2024-11-24 21:30:03 - INFO - Recipient: student@example.com
```

## Dependencies Installation

Before running, ensure these packages are installed:

```bash
pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client
```

## Notes

- The skill uses HTML formatting to make URLs clickable in the email
- Both plain text and HTML versions are included for email client compatibility
- Drafts can be found in the Gmail Drafts folder and edited/sent manually
- Token persistence reduces authentication prompts on subsequent runs
- All file operations use relative paths from the current working directory
