"""
Gmail Draft Sender
Creates draft emails in Gmail using the Gmail API

Usage:
    from send_draft import send_to_draft

    draft_id = send_to_draft(
        email_address="student@example.com",
        subject="Exercise Feedback",
        url="https://github.com/user/repo/pull/123",
        text_to_send="Great work on your submission!",
        recipient_name="John"
    )
"""

import os
import pickle
import base64
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Gmail API scope for creating drafts
SCOPES = ['https://www.googleapis.com/auth/gmail.compose']


def setup_logging(log_file='./files/gmail_draft_log.txt'):
    """
    Configure logging for the draft creation process

    Args:
        log_file: Path to the log file
    """
    # Create files directory if it doesn't exist
    os.makedirs(os.path.dirname(log_file), exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )


def authenticate_gmail():
    """
    Authenticate with Gmail API using credentials.json

    Returns:
        Gmail API service object

    Raises:
        FileNotFoundError: If credentials.json is not found
        Exception: For other authentication errors
    """
    creds = None

    # Check if we have stored credentials
    if os.path.exists('token.pickle'):
        try:
            with open('token.pickle', 'rb') as token:
                creds = pickle.load(token)
                logging.info("Loaded existing credentials from token.pickle")
        except Exception as e:
            logging.warning(f"Failed to load token.pickle: {str(e)}")
            creds = None

    # If no valid credentials, authenticate
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                logging.info("Refreshing expired credentials...")
                creds.refresh(Request())
                logging.info("Credentials refreshed successfully")
            except Exception as e:
                logging.error(f"Failed to refresh credentials: {str(e)}")
                creds = None

        if not creds:
            # Check if credentials.json exists
            if not os.path.exists('credentials.json'):
                logging.error("credentials.json not found in current directory")
                raise FileNotFoundError(
                    "credentials.json not found. Please ensure it's in the current directory."
                )

            try:
                logging.info("Starting new authentication flow...")
                flow = InstalledAppFlow.from_client_secrets_file(
                    'credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)
                logging.info("Authentication successful")
            except Exception as e:
                logging.error(f"Authentication failed: {str(e)}")
                raise

        # Save credentials for next run
        try:
            with open('token.pickle', 'wb') as token:
                pickle.dump(creds, token)
                logging.info("Credentials saved to token.pickle")
        except Exception as e:
            logging.warning(f"Failed to save token.pickle: {str(e)}")

    try:
        service = build('gmail', 'v1', credentials=creds)
        logging.info("Gmail API service created successfully")
        return service
    except Exception as e:
        logging.error(f"Failed to build Gmail service: {str(e)}")
        raise


def create_draft_message(to_email, subject, url, text_content, recipient_name):
    """
    Create a properly formatted email message with HTML for clickable links

    Args:
        to_email: Recipient email address
        subject: Email subject line
        url: URL to reference in the email
        text_content: Main body text of the email
        recipient_name: Recipient's name for personalization

    Returns:
        Dictionary containing the encoded message ready for Gmail API
    """
    logging.debug(f"Creating message for {to_email}")

    # Create message container with both plain text and HTML versions
    message = MIMEMultipart('alternative')
    message['To'] = to_email
    message['Subject'] = subject

    # Plain text version
    text_body = f"""Dear {recipient_name},

Regarding the {url}

{text_content}

Best regards"""

    # HTML version with clickable link
    html_body = f"""<html>
  <body>
    <p>Dear {recipient_name},</p>
    <p>Regarding the <a href="{url}">{url}</a></p>
    <p>{text_content}</p>
    <p>Best regards</p>
  </body>
</html>"""

    # Attach both versions
    part1 = MIMEText(text_body, 'plain')
    part2 = MIMEText(html_body, 'html')
    message.attach(part1)
    message.attach(part2)

    # Encode message for Gmail API
    try:
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
        logging.debug("Message encoded successfully")
        return {'message': {'raw': raw_message}}
    except Exception as e:
        logging.error(f"Failed to encode message: {str(e)}")
        raise


def create_gmail_draft(service, draft_message):
    """
    Create a draft email in Gmail

    Args:
        service: Gmail API service object
        draft_message: Encoded message dictionary

    Returns:
        Draft object containing draft ID and message details

    Raises:
        HttpError: If the API call fails
    """
    try:
        draft = service.users().drafts().create(
            userId='me',
            body=draft_message
        ).execute()

        logging.info(f"Draft created successfully with ID: {draft['id']}")
        return draft
    except HttpError as error:
        logging.error(f"HTTP error creating draft: {error}")
        raise
    except Exception as error:
        logging.error(f"Unexpected error creating draft: {error}")
        raise


def send_to_draft(email_address, subject, url, text_to_send, recipient_name):
    """
    Main function to create a Gmail draft

    Args:
        email_address: Recipient email address
        subject: Email subject line
        url: URL to reference in email body
        text_to_send: Main message text
        recipient_name: Recipient's name

    Returns:
        Draft ID if successful, None otherwise
    """
    # Setup logging
    setup_logging()

    logging.info("=" * 60)
    logging.info("Starting Gmail draft creation")
    logging.info(f"Recipient: {recipient_name} <{email_address}>")
    logging.info(f"Subject: {subject}")
    logging.info(f"URL: {url}")
    logging.info("=" * 60)

    try:
        # Authenticate
        logging.info("Authenticating with Gmail API...")
        service = authenticate_gmail()

        # Create message
        logging.info("Creating email message...")
        draft_message = create_draft_message(
            email_address,
            subject,
            url,
            text_to_send,
            recipient_name
        )

        # Create draft
        logging.info("Creating draft in Gmail...")
        draft = create_gmail_draft(service, draft_message)

        draft_id = draft['id']
        logging.info("=" * 60)
        logging.info("SUCCESS! Draft created successfully")
        logging.info(f"Draft ID: {draft_id}")
        logging.info(f"Recipient: {email_address}")
        logging.info(f"Subject: {subject}")
        logging.info("=" * 60)

        return draft_id

    except FileNotFoundError as e:
        logging.error("=" * 60)
        logging.error("FAILED: Credentials file not found")
        logging.error(str(e))
        logging.error("=" * 60)
        return None
    except HttpError as e:
        logging.error("=" * 60)
        logging.error("FAILED: Gmail API error")
        logging.error(f"Error: {str(e)}")
        logging.error("=" * 60)
        return None
    except Exception as e:
        logging.error("=" * 60)
        logging.error("FAILED: Unexpected error")
        logging.error(f"Error: {str(e)}")
        logging.error("=" * 60)
        return None


# Example usage
if __name__ == "__main__":
    # Example: Create a test draft
    draft_id = send_to_draft(
        email_address="test@example.com",
        subject="Test Draft Email",
        url="https://github.com/example/repo/pull/123",
        text_to_send="This is a test message.\n\nPlease review the code at the URL above.",
        recipient_name="Test User"
    )

    if draft_id:
        print(f"\n✅ Draft created successfully!")
        print(f"Draft ID: {draft_id}")
    else:
        print("\n❌ Failed to create draft. Check the log file for details.")
