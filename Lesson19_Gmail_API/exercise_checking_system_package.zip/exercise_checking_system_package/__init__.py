"""
Exercise Checking System Package
Author: Yair Levi

This package provides an automated system for retrieving, analyzing,
grading, and providing feedback for student exercise submissions.
"""

__version__ = "1.0.0"
__author__ = "Yair Levi"
