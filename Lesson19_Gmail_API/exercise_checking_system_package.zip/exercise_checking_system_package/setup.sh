#!/bin/bash
# Setup script for Exercise Checking System
# Author: Yair Levi

echo "========================================"
echo "Exercise Checking System - Setup"
echo "========================================"
echo

# Check Python version
echo "Checking Python version..."
python3 --version
if [ $? -ne 0 ]; then
    echo "Error: Python 3 is not installed"
    exit 1
fi
echo "✓ Python 3 found"
echo

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv
if [ $? -ne 0 ]; then
    echo "Error: Failed to create virtual environment"
    exit 1
fi
echo "✓ Virtual environment created"
echo

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
echo "✓ Virtual environment activated"
echo

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip
echo

# Install dependencies
echo "Installing dependencies from requirements.txt..."
pip install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "Error: Failed to install dependencies"
    exit 1
fi
echo "✓ Dependencies installed"
echo

# Create necessary directories
echo "Creating directories..."
mkdir -p log
mkdir -p files
mkdir -p temp
echo "✓ Directories created"
echo

# Check for credentials
if [ ! -f "credentials.json" ]; then
    echo "⚠ Warning: credentials.json not found"
    echo "  Please place your Gmail API credentials.json in this directory"
else
    echo "✓ credentials.json found"
fi
echo

echo "========================================"
echo "Setup completed successfully!"
echo "========================================"
echo
echo "To run the application:"
echo "  1. Activate virtual environment: source venv/bin/activate"
echo "  2. Run the program: python3 main.py"
echo
