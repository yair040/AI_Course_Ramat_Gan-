#!/usr/bin/env python3
"""
Code Quality Analysis Script
Analyzes Python code files in exercise directories and calculates grades based on line count metrics.
"""

import os
import csv
from pathlib import Path
from datetime import datetime
import pandas as pd

class CodeAnalyzer:
    def __init__(self, base_dir, input_csv):
        self.base_dir = Path(base_dir)
        self.input_csv = input_csv
        self.log_entries = []
        self.results = []

    def log(self, message):
        """Add a log entry with timestamp"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"[{timestamp}] {message}"
        self.log_entries.append(log_message)
        print(log_message)

    def count_lines_in_file(self, file_path):
        """Count non-empty lines in a Python file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                # Count non-empty lines (strip whitespace)
                non_empty_lines = sum(1 for line in lines if line.strip())
                return non_empty_lines
        except Exception as e:
            self.log(f"ERROR: Could not read file {file_path}: {e}")
            return 0

    def find_code_files(self, directory):
        """Find all Python code files in the directory"""
        code_files = []
        code_extensions = ['.py', '.js', '.java', '.cpp', '.c', '.rb', '.go', '.rs', '.ts', '.jsx', '.tsx']

        dir_path = Path(directory)
        if not dir_path.exists():
            self.log(f"WARNING: Directory does not exist: {directory}")
            return code_files

        # Find all code files recursively
        for ext in code_extensions:
            code_files.extend(dir_path.glob(f"**/*{ext}"))

        return code_files

    def analyze_exercise(self, exercise_id, exercise_dir):
        """Analyze a single exercise directory and calculate grade"""
        self.log(f"\n{'='*60}")
        self.log(f"Analyzing Exercise ID: {exercise_id}")
        self.log(f"Directory: {exercise_dir}")

        # Find all code files
        code_files = self.find_code_files(exercise_dir)

        if not code_files:
            self.log(f"WARNING: No code files found in {exercise_dir}")
            return {
                'id': exercise_id,
                'grade': 'N/A',
                'status': 'error',
                'reason': 'No code files found'
            }

        self.log(f"Found {len(code_files)} code files")

        # Analyze each file
        total_lines_all_files = 0
        total_lines_under_150 = 0
        files_under_150 = []

        for code_file in code_files:
            line_count = self.count_lines_in_file(code_file)
            total_lines_all_files += line_count

            if line_count < 150:
                total_lines_under_150 += line_count
                files_under_150.append(code_file.name)
                self.log(f"  {code_file.name}: {line_count} lines (< 150)")
            else:
                self.log(f"  {code_file.name}: {line_count} lines")

        # Calculate grade
        if total_lines_all_files == 0:
            self.log("ERROR: Total lines is 0, cannot calculate grade")
            grade = 'N/A'
            status = 'error'
        else:
            grade = (total_lines_under_150 / total_lines_all_files) * 100
            grade = round(grade, 2)
            status = 'done'

            self.log(f"\nGrade Calculation:")
            self.log(f"  Files under 150 lines: {len(files_under_150)}")
            self.log(f"  Lines in files under 150: {total_lines_under_150}")
            self.log(f"  Total lines in all files: {total_lines_all_files}")
            self.log(f"  Grade: ({total_lines_under_150} / {total_lines_all_files}) * 100 = {grade}%")

        return {
            'id': exercise_id,
            'grade': grade,
            'status': status,
            'total_files': len(code_files),
            'files_under_150': len(files_under_150),
            'total_lines': total_lines_all_files,
            'lines_under_150': total_lines_under_150
        }

    def run_analysis(self):
        """Main analysis routine"""
        self.log("="*60)
        self.log("CODE QUALITY ANALYSIS STARTED")
        self.log("="*60)

        # Read input CSV
        try:
            df = pd.read_csv(self.input_csv)
            self.log(f"Loaded input CSV: {self.input_csv}")
            self.log(f"Found {len(df)} exercises to analyze")
        except Exception as e:
            self.log(f"ERROR: Could not read input CSV: {e}")
            return

        # Map exercise directories to IDs based on subject
        exercise_mapping = {
            'exercise #9': 'exercise_9',
            'exercise #16': 'exercise_16',
            'exercise #17': 'exercise_17',
            'exercise #18': 'exercise_18'
        }

        # Analyze each exercise
        for _, row in df.iterrows():
            exercise_id = row['id']
            subject = row['subject']

            # Find the exercise directory
            exercise_dir = None
            for key, dir_name in exercise_mapping.items():
                if key in subject:
                    exercise_dir = self.base_dir / dir_name
                    break

            if exercise_dir is None:
                self.log(f"WARNING: Could not map subject '{subject}' to a directory")
                self.results.append({
                    'id': exercise_id,
                    'grade': 'N/A',
                    'status': 'error'
                })
                continue

            # Analyze the exercise
            result = self.analyze_exercise(exercise_id, exercise_dir)
            self.results.append(result)

        self.log("\n" + "="*60)
        self.log("ANALYSIS COMPLETE")
        self.log("="*60)

        # Calculate summary statistics
        valid_grades = [r['grade'] for r in self.results if isinstance(r['grade'], (int, float))]
        if valid_grades:
            avg_grade = sum(valid_grades) / len(valid_grades)
            self.log(f"\nSummary Statistics:")
            self.log(f"  Total exercises analyzed: {len(self.results)}")
            self.log(f"  Valid grades: {len(valid_grades)}")
            self.log(f"  Average grade: {avg_grade:.2f}%")
            self.log(f"  Min grade: {min(valid_grades):.2f}%")
            self.log(f"  Max grade: {max(valid_grades):.2f}%")

    def save_results(self, output_dir):
        """Save results to CSV and log file"""
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True, parents=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Save CSV report
        csv_file = output_dir / f"code_analysis_report_{timestamp}.csv"
        df = pd.DataFrame(self.results)
        # Only keep id, grade, status columns for the report
        df_report = df[['id', 'grade', 'status']]
        df_report.to_csv(csv_file, index=False)
        self.log(f"\nReport saved to: {csv_file}")

        # Save Excel report
        excel_file = output_dir / f"code_analysis_report_{timestamp}.xlsx"
        df_report.to_excel(excel_file, index=False, sheet_name='Code Analysis')
        self.log(f"Excel report saved to: {excel_file}")

        # Save log file
        log_file = output_dir / "log.txt"
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(self.log_entries))
        self.log(f"Log file saved to: {log_file}")

        return csv_file, excel_file, log_file

def get_latest_csv(files_dir):
    """Find the most recent gmail_extract CSV file."""
    csv_files = list(files_dir.glob("gmail_extract_*.csv"))
    if not csv_files:
        raise FileNotFoundError("No gmail_extract CSV files found")
    return max(csv_files, key=lambda f: f.stat().st_mtime)

def main():
    # Configuration - use relative paths from script location
    script_dir = Path(__file__).parent
    base_dir = script_dir / "../../temp/python_files"
    files_dir = script_dir / "../../files"

    # Get the latest CSV file
    try:
        input_csv = get_latest_csv(files_dir)
        print(f"Using CSV file: {input_csv.name}")
    except FileNotFoundError as e:
        print(f"ERROR: {e}")
        return

    output_dir = files_dir

    # Create analyzer and run
    analyzer = CodeAnalyzer(base_dir.resolve(), str(input_csv))
    analyzer.run_analysis()
    csv_file, excel_file, log_file = analyzer.save_results(output_dir.resolve())

    print("\n" + "="*60)
    print("OUTPUT FILES:")
    print(f"  CSV Report: {csv_file}")
    print(f"  Excel Report: {excel_file}")
    print(f"  Log File: {log_file}")
    print("="*60)

if __name__ == "__main__":
    main()
