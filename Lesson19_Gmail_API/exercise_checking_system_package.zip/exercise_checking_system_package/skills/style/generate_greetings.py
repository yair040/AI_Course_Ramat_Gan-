#!/usr/bin/env python3
"""
Greeting Style Generator
Generates personalized greetings based on student grades using different character styles.
Author: Yair Levi
"""

import csv
import random
from pathlib import Path
from datetime import datetime


class GreetingGenerator:
    """Generate personalized greetings in different character styles."""

    def __init__(self):
        self.base_dir = Path(__file__).parent.parent.parent
        self.files_dir = self.base_dir / "files"

    def categorize_grade(self, grade):
        """
        Categorize grade into one of 4 levels.

        Args:
            grade: Numeric grade value (0-100)

        Returns:
            str: Category name ('highest', 'second', 'third', 'lowest')
        """
        grade = float(grade)

        if grade >= 85:
            return 'highest'  # Trump
        elif grade >= 70:
            return 'second'   # Benny Hill
        elif grade >= 50:
            return 'third'    # Kramer
        else:
            return 'lowest'   # Chandler

    def generate_trump_greeting(self):
        """Generate a greeting in Trump's style."""
        templates = [
            "Incredible work! This is absolutely tremendous code - probably the best I've seen all week. You're going to be a fantastic developer, believe me!",
            "Let me tell you, this is amazing code. Nobody writes code better than you, believe me. Tremendous job, absolutely tremendous!",
            "Wow! This is fantastic work. The best code, truly the best. Everyone's talking about how great this is. You should be very proud!",
            "This is huge! Your code is tremendous - and I know tremendous when I see it. You're going to do amazing things, mark my words!",
            "Outstanding! This code is wonderful, absolutely wonderful. Nobody does it better. You're a winner, a real winner!",
            "Spectacular work! Your code is the best, truly exceptional. I've seen a lot of code, and this is top tier. Believe me, you're going places!",
        ]
        return random.choice(templates)

    def generate_benny_hill_greeting(self):
        """Generate a greeting in Benny Hill's style."""
        templates = [
            "Well done, you clever thing! Your code is almost as neat as my tie - and that's saying something! Keep up the cheeky good work!",
            "Cor blimey! That's some lovely code you've got there. Not bad at all, not bad at all! A cheeky bit of brilliance, I'd say!",
            "Oh my, what a lovely piece of work! Your code's got more charm than a British summer's day. Jolly good show!",
            "Ooh, very nice indeed! Your code is as smooth as a cup of proper tea. Keep it up, you clever clogs!",
            "Well, well, well! That's some cheeky coding right there. Almost as good as my dance moves! Splendid effort!",
            "Blimey! Your code's got more pizzazz than a Friday night variety show. Absolutely smashing work, old bean!",
        ]
        return random.choice(templates)

    def generate_kramer_greeting(self):
        """Generate a greeting in Kramer's style."""
        templates = [
            "Hey buddy! Your code is like a pizza - even when it's not perfect, it's still pretty good! Keep that energy going!",
            "Giddy up! Yeah! Your code's got potential, real potential. It's like a subway train - gets you there but might be a bumpy ride!",
            "Hey! Listen to this - your code reminds me of my idea for periscope glasses. It works, but could use some refinement. Keep at it!",
            "Yo! You know what? Your code is like a cup of coffee - hits the spot but leaves room for improvement. Yeah!",
            "Hey pal! Your code's got character, real character! Like that time I tried to make my own cologne. Keep experimenting!",
            "Buddy! Your code is wild, man. It's like a rollercoaster at an amusement park - thrilling but a little unpredictable. Keep that spirit!",
        ]
        return random.choice(templates)

    def generate_chandler_greeting(self):
        """Generate a greeting in Chandler's style."""
        templates = [
            "Could this BE any more of a learning opportunity? But seriously, we all start somewhere. I once wrote code that made my computer cry.",
            "Okay, so... this code needs some work. But hey, could MY first attempts have been any worse? At least your computer still turns on!",
            "Well, this is... educational. Y'know, I'm not saying it's bad, I'm just saying there's room for growth. Like, a LOT of room.",
            "So this is what we're working with? Okay. Not great, not terrible. Actually, maybe a bit terrible. But fixable! Totally fixable.",
            "Alright, I'm not gonna sugarcoat this - there's work to be done. But hey, at least you tried, right? That's more than I can say about my gym membership.",
            "Could this code use some improvement? Oh yeah. But you know what? Everyone starts somewhere. And you started... here. We'll work on it.",
        ]
        return random.choice(templates)

    def generate_greeting(self, category):
        """
        Generate a greeting based on the category.

        Args:
            category: Category name ('highest', 'second', 'third', 'lowest')

        Returns:
            str: Generated greeting
        """
        generators = {
            'highest': self.generate_trump_greeting,
            'second': self.generate_benny_hill_greeting,
            'third': self.generate_kramer_greeting,
            'lowest': self.generate_chandler_greeting
        }

        generator = generators.get(category, self.generate_chandler_greeting)
        return generator()

    def find_latest_code_analysis(self):
        """Find the most recent code analysis report."""
        pattern = "code_analysis_report_*.csv"
        matching_files = list(self.files_dir.glob(pattern))

        if not matching_files:
            raise FileNotFoundError(f"No code analysis report found in {self.files_dir}")

        return max(matching_files, key=lambda p: p.stat().st_mtime)

    def process_greetings(self):
        """
        Main processing function.
        Reads code analysis report and generates personalized greetings.
        """
        print("Starting greeting generation...")

        # Find input file
        input_file = self.find_latest_code_analysis()
        print(f"Reading from: {input_file.name}")

        # Create output file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = self.files_dir / f"personalized_greetings_{timestamp}.csv"

        # Read input and generate greetings
        greetings_data = []

        with open(input_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                student_id = row['id']
                grade = float(row['grade'])

                # Categorize and generate greeting
                category = self.categorize_grade(grade)
                greeting = self.generate_greeting(category)

                greetings_data.append({
                    'id': student_id,
                    'greeting': greeting,
                    'status': 'done'
                })

                print(f"Generated {category} greeting for ID {student_id} (grade: {grade})")

        # Write output
        with open(output_file, 'w', encoding='utf-8', newline='') as f:
            fieldnames = ['id', 'greeting', 'status']
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(greetings_data)

        print(f"\nGreetings saved to: {output_file.name}")
        print(f"Total greetings generated: {len(greetings_data)}")

        return True


def main():
    """Entry point for the script."""
    try:
        generator = GreetingGenerator()
        success = generator.process_greetings()

        if success:
            print("\n✓ Greeting generation completed successfully")
            return 0
        else:
            print("\n✗ Greeting generation failed")
            return 1

    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())
