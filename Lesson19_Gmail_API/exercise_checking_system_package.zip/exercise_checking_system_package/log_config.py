"""
Logging Configuration Module
Implements ring buffer logging with 20 files of 16MB each
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path


class RingBufferLogger:
    """
    Manages ring buffer logging configuration.
    20 files × 16MB with automatic rotation.
    """

    LOG_DIR = Path(__file__).parent / "log"
    MAX_BYTES = 16 * 1024 * 1024  # 16MB
    BACKUP_COUNT = 19  # 20 files total (1 current + 19 backups)
    LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    DATE_FORMAT = '%Y-%m-%d %H:%M:%S'

    @classmethod
    def setup_logger(cls, name, level=logging.INFO):
        """
        Set up a logger with ring buffer configuration.

        Args:
            name: Logger name (typically module name or agent name)
            level: Logging level (default: INFO)

        Returns:
            Configured logger instance
        """
        # Create log directory if it doesn't exist
        cls.LOG_DIR.mkdir(exist_ok=True)

        # Create logger
        logger = logging.getLogger(name)
        logger.setLevel(level)

        # Prevent duplicate handlers
        if logger.handlers:
            return logger

        # Create rotating file handler
        log_file = cls.LOG_DIR / f"{name}.log"
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=cls.MAX_BYTES,
            backupCount=cls.BACKUP_COUNT,
            encoding='utf-8'
        )
        file_handler.setLevel(level)

        # Create console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)

        # Create formatter
        formatter = logging.Formatter(
            cls.LOG_FORMAT,
            datefmt=cls.DATE_FORMAT
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Add handlers
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

        return logger

    @classmethod
    def get_logger(cls, name, level=logging.INFO):
        """
        Get or create a logger instance.

        Args:
            name: Logger name
            level: Logging level

        Returns:
            Logger instance
        """
        return cls.setup_logger(name, level)


def get_main_logger():
    """Get the main program logger."""
    return RingBufferLogger.get_logger("main")


def get_agent_logger(agent_name):
    """Get a logger for a specific agent."""
    return RingBufferLogger.get_logger(f"agent_{agent_name}")
